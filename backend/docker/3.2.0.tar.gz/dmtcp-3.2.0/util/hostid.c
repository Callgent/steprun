#include <stdio.h>
#include <unistd.h>
void
main()
{
  printf("%d\n", gethostid());
}
